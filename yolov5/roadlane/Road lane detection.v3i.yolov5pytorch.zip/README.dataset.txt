# Road lane detection > 2023-06-02 6:55pm
https://universe.roboflow.com/makariy-xodcv/road-lane-detection

Provided by a Roboflow user
License: CC BY 4.0

